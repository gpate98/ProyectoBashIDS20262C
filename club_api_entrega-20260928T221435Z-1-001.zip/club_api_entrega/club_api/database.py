import sqlite3

DATABASE = "club.db"


def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    db = get_db()

    db.execute("PRAGMA foreign_keys = ON;")

    db.execute("""
    CREATE TABLE IF NOT EXISTS deportes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL
    );
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS canchas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        id_deporte INTEGER NOT NULL,
        precio_hora INTEGER NOT NULL CHECK(precio_hora > 0),
        techada INTEGER NOT NULL DEFAULT 0,
        activa INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (id_deporte) REFERENCES deportes(id)
    );
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS socios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        activo INTEGER NOT NULL DEFAULT 1
    );
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS reservas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_socio INTEGER NOT NULL,
        id_cancha INTEGER NOT NULL,
        fecha_hora_inicio TEXT NOT NULL,
        fecha_hora_fin TEXT NOT NULL,
        estado TEXT NOT NULL,
        precio_hora INTEGER NOT NULL,
        precio_total INTEGER NOT NULL,
        FOREIGN KEY (id_socio) REFERENCES socios(id),
        FOREIGN KEY (id_cancha) REFERENCES canchas(id)
    );
    """)

    cantidad = db.execute("SELECT COUNT(*) FROM deportes").fetchone()[0]
    if cantidad == 0:
        db.execute("INSERT INTO deportes (nombre) VALUES ('Fútbol')")
        db.execute("INSERT INTO deportes (nombre) VALUES ('Tenis')")
        db.execute("INSERT INTO deportes (nombre) VALUES ('Pádel')")

    db.commit()
    db.close()

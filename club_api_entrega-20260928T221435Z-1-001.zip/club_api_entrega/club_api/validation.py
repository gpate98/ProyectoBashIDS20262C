from datetime import datetime

FORMATO = "%Y-%m-%dT%H:%M:%S.000000-03:00"


def parse_datetime(text):
    try:
        return datetime.strptime(text, FORMATO)
    except (ValueError, TypeError):
        return None


def validar_datetime_reserva(inicio_texto, fin_texto):
    inicio = parse_datetime(inicio_texto)
    fin = parse_datetime(fin_texto)

    if inicio is None or fin is None:
        return (
            None,
            None,
            "Las fechas deben tener formato ISO 8601 con GMT-3 y 6 decimales",
        )

    if inicio >= fin:
        return (
            None,
            None,
            "La fecha_hora_inicio debe ser anterior a fecha_hora_fin",
        )

    ahora = datetime.now()
    if inicio <= ahora:
        return None, None, "La reserva debe comenzar en el futuro"

    if inicio.date() != fin.date():
        return None, None, "La reserva no puede atravesar la medianoche"

    if inicio.minute != 0 or inicio.second != 0:
        return None, None, "El inicio debe estar en una hora exacta"

    if fin.minute != 0 or fin.second != 0:
        return None, None, "El fin debe estar en una hora exacta"

    if inicio.hour < 8 or fin.hour > 23:
        return (
            None,
            None,
            "La reserva debe estar dentro del horario 08:00 a 23:00",
        )

    horas = fin.hour - inicio.hour
    if horas < 1 or horas > 3:
        return None, None, "La reserva debe durar entre 1 y 3 horas"

    return inicio, fin, None


def validar_email(email):

    if not isinstance(email, str):
        return False

    texto = email.strip()

    if "@" not in texto:
        return False
    if " " in texto:
        return False

    partes = texto.split("@")
    if len(partes) != 2:
        return False

    usuario = partes[0]
    dominio = partes[1]

    if not usuario or not dominio:
        return False

    if "." not in dominio:
        return False

    return True


def validar_booleano(valor):
    if isinstance(valor, bool):
        return True
    else:
        return False


def validar_entero_positivo(valor):
    if isinstance(valor, int) and not isinstance(valor, bool):
        if valor > 0:
            return True
    return False


def solapan(inicio1, fin1, inicio2, fin2):
    if inicio1 < fin2 and inicio2 < fin1:
        return True
    else:
        return False

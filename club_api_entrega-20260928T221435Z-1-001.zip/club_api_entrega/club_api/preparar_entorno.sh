#!/bin/bash

code .

sudo apt install pipenv -y --ignore-missing
pipenv install flask

clear
echo "Entorno virtual creado exitosamente!"
pipenv shell

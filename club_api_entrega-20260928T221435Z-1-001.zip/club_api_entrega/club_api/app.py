from datetime import datetime, date
from urllib.parse import urlencode
from flask import Flask, jsonify, request

from database import get_db, init_db
from validation import (
    parse_datetime,
    solapan,
    validar_booleano,
    validar_datetime_reserva,
    validar_email,
    validar_entero_positivo,
)

app = Flask(__name__)
init_db()

ESTADOS = ["confirmada", "cancelada", "finalizada"]


def error(mensaje, codigo="ERROR_VALIDACION", estado=400):
    return (
        jsonify(
            {
                "errors": [
                    {
                        "code": codigo,
                        "message": mensaje,
                        "level": "error",
                        "description": mensaje,
                    }
                ]
            }
        ),
        estado,
    )


def fila_a_diccionario(fila):
    return dict(fila) if fila else None


def valor_booleano(valor):
    return bool(valor)


def cancha_a_diccionario(fila):
    datos = fila_a_diccionario(fila)
    if datos:
        datos["techada"] = valor_booleano(datos["techada"])
        datos["activa"] = valor_booleano(datos["activa"])
    return datos


def socio_a_diccionario(fila):
    datos = fila_a_diccionario(fila)
    if datos:
        datos["activo"] = valor_booleano(datos["activo"])
    return datos


def generar_enlaces(limite, desplazamiento, total, parametros):
    if limite <= 0:
        limite = 10
    ultimo_desplazamiento = 0 if total == 0 else ((total - 1) // limite) * limite

    def armar_url(nuevo_desplazamiento):
        p = dict(parametros)
        p["_limit"] = limite
        p["_offset"] = nuevo_desplazamiento
        return request.base_url + "?" + urlencode(p)

    resultado = {
        "_first": {"href": armar_url(0)},
        "_prev": {"href": armar_url(max(0, desplazamiento - limite))},
        "_next": {
            "href": armar_url(min(ultimo_desplazamiento, desplazamiento + limite))
        },
        "_last": {"href": armar_url(ultimo_desplazamiento)},
    }
    return resultado


def valores_paginacion():
    try:
        limite = int(request.args.get("_limit", 10))
        desplazamiento = int(request.args.get("_offset", 0))
    except ValueError:
        return None, None, "_limit y _offset deben ser enteros"
    if limite < 1 or limite > 100:
        return None, None, "_limit debe estar entre 1 y 100"
    if desplazamiento < 0:
        return None, None, "_offset debe ser mayor o igual a 0"
    return limite, desplazamiento, None


def verificar_json_desconocido(permitidos):
    datos = request.get_json(silent=True)
    if not isinstance(datos, dict) or not datos:
        return None, error("El cuerpo debe ser un objeto JSON no vacío")
    desconocidos = set(datos.keys()) - set(permitidos)
    if desconocidos:
        return None, error("Hay campos desconocidos en el cuerpo")
    return datos, None


@app.get("/deportes")
def deportes():
    db = get_db()
    filas = db.execute("SELECT id, nombre FROM deportes ORDER BY id").fetchall()
    db.close()
    return jsonify({"deportes": [dict(f) for f in filas]})


@app.get("/canchas")
def listar_canchas():
    limite, desplazamiento, err = valores_paginacion()
    if err:
        return error(err)

    condiciones = []
    valores = []
    parametros = {}

    if request.args.get("id_deporte") is not None:
        try:
            valor = int(request.args["id_deporte"])
        except ValueError:
            return error("id_deporte debe ser entero")
        condiciones.append("id_deporte = ?")
        valores.append(valor)
        parametros["id_deporte"] = valor

    if request.args.get("nombre") is not None:
        condiciones.append("LOWER(nombre) LIKE LOWER(?)")
        valores.append("%" + request.args["nombre"] + "%")
        parametros["nombre"] = request.args["nombre"]

    for nombre_campo in ["techada", "activa"]:
        if request.args.get(nombre_campo) is not None:
            valor = request.args[nombre_campo]
            if valor not in ["true", "false"]:
                return error(nombre_campo + " debe ser true o false")
            booleano = valor == "true"
            condiciones.append(nombre_campo + " = ?")
            valores.append(int(booleano))
            parametros[nombre_campo] = valor

    donde = " WHERE " + " AND ".join(condiciones) if condiciones else ""
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM canchas" + donde, valores).fetchone()[0]
    filas = db.execute(
        "SELECT id, nombre, id_deporte, precio_hora, techada, activa FROM canchas"
        + donde
        + " ORDER BY id LIMIT ? OFFSET ?",
        valores + [limite, desplazamiento],
    ).fetchall()
    db.close()

    return jsonify(
        {
            "canchas": [cancha_a_diccionario(f) for f in filas],
            "_links": generar_enlaces(limite, desplazamiento, total, parametros),
        }
    )


@app.post("/canchas")
def crear_cancha():
    datos, err = verificar_json_desconocido(
        ["nombre", "id_deporte", "precio_hora", "techada", "activa"]
    )
    if err:
        return err

    for campo in ["nombre", "id_deporte", "precio_hora"]:
        if campo not in datos:
            return error("Falta el campo " + campo)

    nombre = datos["nombre"]
    if not isinstance(nombre, str) or not nombre.strip():
        return error("El nombre no puede estar vacío")
    if not validar_entero_positivo(datos["id_deporte"]):
        return error("id_deporte debe ser un entero positivo")
    if not validar_entero_positivo(datos["precio_hora"]):
        return error("precio_hora debe ser un entero positivo")

    techada = datos.get("techada", False)
    activa = datos.get("activa", True)
    if not validar_booleano(techada) or not validar_booleano(activa):
        return error("techada y activa deben ser booleanos")

    db = get_db()
    deporte = db.execute(
        "SELECT id FROM deportes WHERE id = ?", (datos["id_deporte"],)
    ).fetchone()
    if not deporte:
        db.close()
        return error("El deporte no existe", "RECURSO_NO_ENCONTRADO", 404)

    cur = db.execute(
        "INSERT INTO canchas (nombre, id_deporte, precio_hora, techada, activa) VALUES (?, ?, ?, ?, ?)",
        (
            nombre.strip(),
            datos["id_deporte"],
            datos["precio_hora"],
            int(techada),
            int(activa),
        ),
    )
    db.commit()
    fila = db.execute("SELECT * FROM canchas WHERE id = ?", (cur.lastrowid,)).fetchone()
    db.close()
    return jsonify(cancha_a_diccionario(fila)), 201


@app.get("/canchas/<int:identificador>")
def obtener_cancha(identificador):
    db = get_db()
    fila = db.execute("SELECT * FROM canchas WHERE id = ?", (identificador,)).fetchone()
    db.close()
    if not fila:
        return error("La cancha no existe", "RECURSO_NO_ENCONTRADO", 404)
    return jsonify(cancha_a_diccionario(fila))


@app.patch("/canchas/<int:identificador>")
def actualizar_cancha(identificador):
    datos, err = verificar_json_desconocido(
        ["nombre", "precio_hora", "techada", "activa"]
    )
    if err:
        return err

    db = get_db()
    fila = db.execute("SELECT * FROM canchas WHERE id = ?", (identificador,)).fetchone()
    if not fila:
        db.close()
        return error("La cancha no existe", "RECURSO_NO_ENCONTRADO", 404)

    nombre = datos.get("nombre", fila["nombre"])
    precio = datos.get("precio_hora", fila["precio_hora"])
    techada = datos.get("techada", bool(fila["techada"]))
    activa = datos.get("activa", bool(fila["activa"]))

    if not isinstance(nombre, str) or not nombre.strip():
        db.close()
        return error("El nombre no puede estar vacío")
    if not validar_entero_positivo(precio):
        db.close()
        return error("precio_hora debe ser un entero positivo")
    if not validar_booleano(techada) or not validar_booleano(activa):
        db.close()
        return error("techada y activa deben ser booleanos")

    db.execute(
        "UPDATE canchas SET nombre=?, precio_hora=?, techada=?, activa=? WHERE id=?",
        (nombre.strip(), precio, int(techada), int(activa), identificador),
    )
    db.commit()
    db.close()
    return "", 204


@app.delete("/canchas/<int:identificador>")
def eliminar_cancha(identificador):
    db = get_db()
    fila = db.execute(
        "SELECT id FROM canchas WHERE id = ?", (identificador,)
    ).fetchone()
    if not fila:
        db.close()
        return error("La cancha no existe", "RECURSO_NO_ENCONTRADO", 404)
    reserva = db.execute(
        "SELECT id FROM reservas WHERE id_cancha = ? LIMIT 1", (identificador,)
    ).fetchone()
    if reserva:
        db.close()
        return error("No se puede eliminar una cancha con reservas", "CONFLICTO", 409)
    db.execute("DELETE FROM canchas WHERE id = ?", (identificador,))
    db.commit()
    db.close()
    return "", 204


@app.get("/canchas/disponibles")
def canchas_disponibles():
    limite, desplazamiento, err = valores_paginacion()
    if err:
        return error(err)

    fecha = request.args.get("fecha")
    hora_inicio = request.args.get("hora_inicio")
    hora_fin = request.args.get("hora_fin")
    if not fecha or not hora_inicio or not hora_fin:
        return error("fecha, hora_inicio y hora_fin son obligatorios")

    inicio_texto = fecha + "T" + hora_inicio + ".000000-03:00"
    fin_texto = fecha + "T" + hora_fin + ".000000-03:00"
    inicio, fin, mensaje = validar_datetime_reserva(inicio_texto, fin_texto)
    if mensaje:
        return error(mensaje)

    condiciones = ["activa = 1"]
    valores = []
    parametros = {
        "fecha": fecha,
        "hora_inicio": hora_inicio,
        "hora_fin": hora_fin,
    }

    if request.args.get("id_deporte") is not None:
        try:
            id_deporte = int(request.args["id_deporte"])
        except ValueError:
            return error("id_deporte debe ser entero")
        condiciones.append("id_deporte = ?")
        valores.append(id_deporte)
        parametros["id_deporte"] = id_deporte

    if request.args.get("techada") is not None:
        if request.args["techada"] not in ["true", "false"]:
            return error("techada debe ser true o false")
        condiciones.append("techada = ?")
        valores.append(int(request.args["techada"] == "true"))
        parametros["techada"] = request.args["techada"]

    db = get_db()
    filas = db.execute(
        "SELECT * FROM canchas WHERE " + " AND ".join(condiciones) + " ORDER BY id",
        valores,
    ).fetchall()
    disponibles = []
    for cancha in filas:
        reservas = db.execute(
            "SELECT fecha_hora_inicio, fecha_hora_fin FROM reservas WHERE id_cancha=? AND estado='confirmada'",
            (cancha["id"],),
        ).fetchall()
        ocupada = False
        for reserva in reservas:
            r_inicio = parse_datetime(reserva["fecha_hora_inicio"])
            r_fin = parse_datetime(reserva["fecha_hora_fin"])
            if solapan(inicio, fin, r_inicio, r_fin):
                ocupada = True
                break
        if not ocupada:
            disponibles.append(cancha_a_diccionario(cancha))
    db.close()

    total = len(disponibles)
    return jsonify(
        {
            "canchas": disponibles[desplazamiento : desplazamiento + limite],
            "_links": generar_enlaces(limite, desplazamiento, total, parametros),
        }
    )


@app.get("/socios")
def listar_socios():
    limite, desplazamiento, err = valores_paginacion()
    if err:
        return error(err)
    condiciones = []
    valores = []
    parametros = {}

    if request.args.get("nombre") is not None:
        condiciones.append("LOWER(nombre) LIKE LOWER(?)")
        valores.append("%" + request.args["nombre"] + "%")
        parametros["nombre"] = request.args["nombre"]

    if request.args.get("activo") is not None:
        if request.args["activo"] not in ["true", "false"]:
            return error("activo debe ser true o false")
        condiciones.append("activo = ?")
        valores.append(int(request.args["activo"] == "true"))
        parametros["activo"] = request.args["activo"]

    donde = " WHERE " + " AND ".join(condiciones) if condiciones else ""
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM socios" + donde, valores).fetchone()[0]
    filas = db.execute(
        "SELECT * FROM socios" + donde + " ORDER BY id LIMIT ? OFFSET ?",
        valores + [limite, desplazamiento],
    ).fetchall()
    db.close()
    return jsonify(
        {
            "socios": [socio_a_diccionario(f) for f in filas],
            "_links": generar_enlaces(limite, desplazamiento, total, parametros),
        }
    )


@app.post("/socios")
def crear_socio():
    datos, err = verificar_json_desconocido(["nombre", "email"])
    if err:
        return err
    if "nombre" not in datos or "email" not in datos:
        return error("nombre y email son obligatorios")
    if not isinstance(datos["nombre"], str) or not datos["nombre"].strip():
        return error("El nombre no puede estar vacío")
    email = datos["email"].strip().lower() if isinstance(datos["email"], str) else ""
    if not validar_email(email):
        return error("El correo no tiene un formato válido")

    db = get_db()

    existente = db.execute("SELECT id FROM socios WHERE email = ?", (email,)).fetchone()
    if existente:
        db.close()
        return error("El correo ya está registrado", "CONFLICTO", 409)

    cur = db.execute(
        "INSERT INTO socios (nombre, email, activo) VALUES (?, ?, 1)",
        (datos["nombre"].strip(), email),
    )
    db.commit()

    fila = db.execute("SELECT * FROM socios WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return jsonify(socio_a_diccionario(fila)), 201


@app.get("/socios/int:identificador")
def obtener_socio(identificador):
    db = get_db()
    fila = db.execute("SELECT * FROM socios WHERE id=?", (identificador,)).fetchone()
    db.close()
    if not fila:
        return error("El socio no existe", "RECURSO_NO_ENCONTRADO", 404)
    return jsonify(socio_a_diccionario(fila))


@app.patch("/socios/int:identificador")
def actualizar_socio(identificador):
    datos, err = verificar_json_desconocido(["nombre", "email", "activo"])
    if err:
        return err
    db = get_db()
    fila = db.execute("SELECT * FROM socios WHERE id=?", (identificador,)).fetchone()
    if not fila:
        db.close()
        return error("El socio no existe", "RECURSO_NO_ENCONTRADO", 404)

    nombre = datos.get("nombre", fila["nombre"])
    email = datos.get("email", fila["email"])
    activo = datos.get("activo", bool(fila["activo"]))
    if not isinstance(nombre, str) or not nombre.strip():
        db.close()
        return error("El nombre no puede estar vacío")
    if not isinstance(email, str) or not validar_email(email.strip()):
        db.close()
        return error("El correo no tiene un formato válido")
    if not validar_booleano(activo):
        db.close()
        return error("activo debe ser booleano")
    email = email.strip().lower()

    otro_socio = db.execute(
        "SELECT id FROM socios WHERE email=? AND id<>?", (email, identificador)
    ).fetchone()
    if otro_socio:
        db.close()
        return error("El correo ya está registrado", "CONFLICTO", 409)
    db.execute(
        "UPDATE socios SET nombre=?, email=?, activo=? WHERE id=?",
        (nombre.strip(), email, int(activo), identificador),
    )
    db.commit()
    db.close()
    return "", 204


@app.get("/reservas")
def listar_reservas():
    limite, desplazamiento, err = valores_paginacion()
    if err:
        return error(err)
    condiciones = []
    valores = []
    parametros = {}

    for nombre_campo in ["id_cancha", "id_socio"]:
        if request.args.get(nombre_campo) is not None:
            try:
                valor = int(request.args[nombre_campo])
            except ValueError:
                return error(nombre_campo + " debe ser entero")
            condiciones.append(nombre_campo + " = ?")
            valores.append(valor)
            parametros[nombre_campo] = valor

    if request.args.get("estado") is not None:
        if request.args["estado"] not in ESTADOS:
            return error("estado inválido")
        condiciones.append("estado = ?")
        valores.append(request.args["estado"])
        parametros["estado"] = request.args["estado"]

    fecha_desde = request.args.get("fecha_desde")
    fecha_hasta = request.args.get("fecha_hasta")
    try:
        if fecha_desde:
            date.fromisoformat(fecha_desde)
        if fecha_hasta:
            date.fromisoformat(fecha_hasta)
    except ValueError:
        return error("Las fechas deben tener formato YYYY-MM-DD")
    if fecha_desde and fecha_hasta and fecha_desde > fecha_hasta:
        return error("fecha_desde no puede ser mayor que fecha_hasta")
    if fecha_desde:
        condiciones.append("substr(fecha_hora_inicio,1,10) >= ?")
        valores.append(fecha_desde)
        parametros["fecha_desde"] = fecha_desde
    if fecha_hasta:
        condiciones.append("substr(fecha_hora_inicio,1,10) <= ?")
        valores.append(fecha_hasta)
        parametros["fecha_hasta"] = fecha_hasta

    donde = " WHERE " + " AND ".join(condiciones) if condiciones else ""
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM reservas" + donde, valores).fetchone()[0]
    filas = db.execute(
        "SELECT * FROM reservas" + donde + " ORDER BY id LIMIT ? OFFSET ?",
        valores + [limite, desplazamiento],
    ).fetchall()
    db.close()
    return jsonify(
        {
            "reservas": [dict(f) for f in filas],
            "_links": generar_enlaces(limite, desplazamiento, total, parametros),
        }
    )


@app.post("/reservas")
def crear_reserva():
    datos, err = verificar_json_desconocido(
        ["id_socio", "id_cancha", "fecha_hora_inicio", "fecha_hora_fin"]
    )
    if err:
        return err
    for campo in [
        "id_socio",
        "id_cancha",
        "fecha_hora_inicio",
        "fecha_hora_fin",
    ]:
        if campo not in datos:
            return error("Falta el campo " + campo)
    if not validar_entero_positivo(datos["id_socio"]) or not validar_entero_positivo(
        datos["id_cancha"]
    ):
        return error("id_socio e id_cancha deben ser enteros positivos")

    inicio, fin, mensaje = validar_datetime_reserva(
        datos["fecha_hora_inicio"], datos["fecha_hora_fin"]
    )
    if mensaje:
        return error(mensaje)

    db = get_db()
    socio = db.execute(
        "SELECT * FROM socios WHERE id=?", (datos["id_socio"],)
    ).fetchone()
    cancha = db.execute(
        "SELECT * FROM canchas WHERE id=?", (datos["id_cancha"],)
    ).fetchone()
    if not socio or not cancha:
        db.close()
        return error("El socio o la cancha no existen", "RECURSO_NO_ENCONTRADO", 404)
    if not socio["activo"] or not cancha["activa"]:
        db.close()
        return error("El socio y la cancha deben estar activos", "CONFLICTO", 409)

    reservas = db.execute(
        "SELECT * FROM reservas WHERE estado='confirmada' AND (id_cancha=? OR id_socio=?)",
        (datos["id_cancha"], datos["id_socio"]),
    ).fetchall()
    for reserva in reservas:
        r_inicio = parse_datetime(reserva["fecha_hora_inicio"])
        r_fin = parse_datetime(reserva["fecha_hora_fin"])
        if solapan(inicio, fin, r_inicio, r_fin):
            db.close()
            return error("Existe una reserva confirmada superpuesta", "CONFLICTO", 409)

    horas = int((fin - inicio).seconds / 3600)
    precio_hora = cancha["precio_hora"]
    precio_total = horas * precio_hora
    cur = db.execute(
        """INSERT INTO reservas(id_socio, id_cancha, fecha_hora_inicio, fecha_hora_fin, estado, precio_hora, precio_total)
VALUES (?, ?, ?, ?, 'confirmada', ?, ?)""",
        (
            datos["id_socio"],
            datos["id_cancha"],
            datos["fecha_hora_inicio"],
            datos["fecha_hora_fin"],
            precio_hora,
            precio_total,
        ),
    )
    db.commit()
    fila = db.execute("SELECT * FROM reservas WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return jsonify(dict(fila)), 201


@app.get("/reservas/int:identificador")
def obtener_reserva(identificador):
    db = get_db()
    fila = db.execute("SELECT * FROM reservas WHERE id=?", (identificador,)).fetchone()
    db.close()
    if not fila:
        return error("La reserva no existe", "RECURSO_NO_ENCONTRADO", 404)
    return jsonify(dict(fila))


@app.put("/reservas/int:identificador/estado")
def cambiar_estado(identificador):
    datos, err = verificar_json_desconocido(["estado"])
    if err:
        return err
    if "estado" not in datos:
        return error("Falta el campo estado")
    if datos["estado"] not in ESTADOS:
        return error("Estado desconocido")

    db = get_db()
    fila = db.execute("SELECT * FROM reservas WHERE id=?", (identificador,)).fetchone()
    if not fila:
        db.close()
        return error("La reserva no existe", "RECURSO_NO_ENCONTRADO", 404)

    actual = fila["estado"]
    solicitado = datos["estado"]
    if actual == solicitado:
        db.close()
        return jsonify(dict(fila))

    ahora = datetime.now()
    inicio = parse_datetime(fila["fecha_hora_inicio"])
    fin = parse_datetime(fila["fecha_hora_fin"])

    if actual == "confirmada" and solicitado == "cancelada":
        if ahora >= inicio:
            db.close()
            return error("No se puede cancelar después de comenzar", "CONFLICTO", 409)
    elif actual == "confirmada" and solicitado == "finalizada":
        if ahora < fin:
            db.close()
            return error("La reserva todavía no finalizó", "CONFLICTO", 409)
    else:
        db.close()
        return error("La transición de estado no está permitida", "CONFLICTO", 409)

    db.execute("UPDATE reservas SET estado=? WHERE id=?", (solicitado, identificador))
    db.commit()
    fila = db.execute("SELECT * FROM reservas WHERE id=?", (identificador,)).fetchone()
    db.close()
    return jsonify(dict(fila))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

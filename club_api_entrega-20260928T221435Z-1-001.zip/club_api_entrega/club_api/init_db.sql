PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS deportes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS canchas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    id_deporte INTEGER NOT NULL,
    precio_hora INTEGER NOT NULL,
    techada INTEGER NOT NULL DEFAULT 0,
    activa INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (id_deporte) REFERENCES deportes(id)
);

CREATE TABLE IF NOT EXISTS socios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_socio INTEGER NOT NULL,
    id_cancha INTEGER NOT NULL,
    fecha_hora_inicio TEXT NOT NULL,
    fecha_hora_fin TEXT NOT NULL,
    estado TEXT NOT NULL,
    precio_hora INTEGER NOT NULL,
    precio_total INTEGER NOT NULL,
    FOREIGN KEY (id_socio) REFERENCES socios(id),
    FOREIGN KEY (id_cancha) REFERENCES canchas(id)
);

INSERT INTO deportes (nombre)
SELECT 'Fútbol' WHERE NOT EXISTS (SELECT 1 FROM deportes WHERE nombre = 'Fútbol');
INSERT INTO deportes (nombre)
SELECT 'Tenis' WHERE NOT EXISTS (SELECT 1 FROM deportes WHERE nombre = 'Tenis');
INSERT INTO deportes (nombre)
SELECT 'Pádel' WHERE NOT EXISTS (SELECT 1 FROM deportes WHERE nombre = 'Pádel');

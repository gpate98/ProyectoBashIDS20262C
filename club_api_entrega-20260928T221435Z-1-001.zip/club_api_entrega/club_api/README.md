# API de Reservas de Club Deportivo

Proyecto backend desarrollado para el trabajo práctico de la materia en FIUBA.

## Tecnologías

- Python 3
- Flask
- SQLite (base de datos relacional integrada para simplificar ejecución)
- Swagger / OpenAPI (Contrato de la API provisto en `openapi.yaml`)

## Instalación y Ejecución

1. Crear y activar un entorno virtual de Python:

```bash
python3 -m venv venv
source venv/bin/activate
```

2. Instalar la dependencia requerida:

```bash
pip install -r requirements.txt
```

3. Iniciar el servidor de desarrollo:

```bash
python3 app.py
```

La API quedará disponible de forma local en `http://localhost:5000`. 
Al ejecutarse por primera vez, el sistema creará automáticamente el archivo de base de datos `club.db` y cargará los deportes iniciales (Fútbol, Tenis, Pádel).

## Endpoints Implementados

El backend cubre de forma estricta la totalidad del alcance obligatorio definido en el enunciado:

- **Deportes:** `GET /deportes`
- **Canchas:** `GET /canchas`, `POST /canchas`, `GET /canchas/{id}`, `PATCH /canchas/{id}`, `DELETE /canchas/{id}`, `GET /canchas/disponibles`
- **Socios:** `GET /socios`, `POST /socios`, `GET /socios/{id}`, `PATCH /socios/{id}`
- **Reservas:** `GET /reservas`, `POST /reservas`, `GET /reservas/{id}`, `PUT /reservas/{id}/estado`

## Ejemplos de Solicitudes (JSON)

### Registrar un Socio (`POST /socios`)
```json
{
  "nombre": "Juan Pérez",
  "email": "juan.perez@example.com"
}
```

### Crear una Cancha (`POST /canchas`)
```json
{
  "nombre": "Cancha de Tenis 1",
  "id_deporte": 2,
  "precio_hora": 1200000,
  "techada": true,
  "activa": true
}
```

### Crear una Reserva (`POST /reservas`)
*Nota: Se debe ingresar siempre una fecha y horario futuros al momento de realizar la prueba.*
```json
{
  "id_socio": 1,
  "id_cancha": 1,
  "fecha_hora_inicio": "2026-10-15T18:00:00.000000-03:00",
  "fecha_hora_fin": "2026-10-15T20:00:00.000000-03:00"
}
```

## Notas sobre el Alcance y Supuestos

- **Estructura OpenAPI:** El archivo de contrato `openapi.yaml` incluye el diseño estructural para futuras extensiones del negocio (Bloqueos de mantenimiento y Reservas recurrentes). De acuerdo con las especificaciones del trabajo práctico, el servidor actual materializa de forma completa el flujo básico obligatorio.
- **Validación de Negocio:** La lógica interna resuelve de forma lineal el control de horarios del club (08:00 a 23:00), duraciones permitidas (1 a 3 horas), estados de cancelación/finalización históricos, consistencia de precios en centavos y la prevención total de superposiciones horarias tanto para las canchas como para los socios.
- **Estilo de Código:** Se priorizó el desarrollo de funciones modulares e independientes utilizando tipos nativos de Python y consultas SQL directas por parámetros para evitar inyecciones, manteniendo una estructura simple, legible y libre de advertencias en herramientas de análisis estático como Pylint.